<?php

namespace Snapchat\API\Request\Model;

class SendMediaPayload {

    public $time;
    public $type;
    public $media_id;
    public $zipped;
    public $recipients;
    public $recipient_ids;
    public $set_as_story;

}