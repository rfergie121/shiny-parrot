<?php

namespace Snapchat\API\Request\Model;

class UploadMediaPayload {

    public $file;
    public $type;
    public $media_id;

}