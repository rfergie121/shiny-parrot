<?php

namespace Casper\Developer\Exception;

use Exception;

class CasperException extends Exception {

}