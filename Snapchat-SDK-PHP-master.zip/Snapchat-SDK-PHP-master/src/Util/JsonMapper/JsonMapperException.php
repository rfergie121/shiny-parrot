<?php

namespace Snapchat\Util\JsonMapper;

use Exception;

class JsonMapper_Exception extends Exception {

}