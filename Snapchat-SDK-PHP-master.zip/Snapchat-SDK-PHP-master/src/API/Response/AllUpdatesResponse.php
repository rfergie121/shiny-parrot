<?php

namespace Snapchat\API\Response;

class AllUpdatesResponse extends LoginResponse {

}